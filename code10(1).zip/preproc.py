import numpy as np
from sklearn import preprocessing
from scipy.stats import anderson


rain = np.load('rain.npy')#数据加载到数组中

rain = .1 * rain#全部数据乘以0.1得到毫米为单位的降雨量数据
rain[rain < 0] = .05/2#小于0.05的数据全部/2

print ("Rain mean", rain.mean())#平均值，std标准差
print ("Rain variance", rain.var())

print ("Anderson rain", anderson(rain))#安德森检验第一种情况期望值和方差已知，，
#scipy.stats.anderson
#第一个为统计数，第二个为评判值，第三个为显著性水平， 评判值与显著性水平对应 
#对于正态性检验，显著性水平为：15%, 10%, 5%, 2.5%, 1%

#期望值标准差安德森达林检验结果 ，解释？？？
scaled = preprocessing.scale(rain)#对数据进行缩放处理
print ("Scaled mean", scaled.mean())
print( "Scaled variance", scaled.var())
print ("Anderson scaled", anderson(scaled)) 
print (len(rain[rain < 0]))#不存在小于0的数据  
a1=np.linspace(0,39138,39139)
a2=rain
c=np.c_[a1,a2]
#d=np.r_[a1,a1]
#rain["index_rain"]=np.linspace(0,39138,39138)
binarized = preprocessing.binarize(c,threshold=0.0)

print ('binarized：',np.unique(binarized))

lb = preprocessing.LabelBinarizer()
lb.fit(rain.astype(int))
print(lb.classes_)


