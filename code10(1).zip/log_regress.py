from sklearn.linear_model import LogisticRegression
from sklearn.cross_validation import KFold
from sklearn import datasets
import numpy as np

#定义方法分类
def classify(x, y):#使用逻辑回归进行分类
    clf = LogisticRegression(random_state=12)#创建分类器对象，参数的作用为随机数生成器指定的种子
    scores = []
    #K-折交叉验证，把数据集随机分为K份；
    #每一份称为一个包，在K次迭代过程中，每个包会有一次被用于验证，其余九次用于训练；
    #通常需要将这个值设置的更大一些如5/10；
    #迭代的结果可以在最后进行合并
    kf = KFold(len(y), n_folds=10)#scikit-learn提供了一个KFold类，创建一个具有10个包的KFold对象
    #检查分类的状态
    for train,test in kf:
      clf.fit(x[train], y[train])#fit函数训练数据
      scores.append(clf.score(x[test], y[test]))#衡量分类的准确性，使用score（）函数

    print( np.mean(scores))
    
    
    
#加载数据信息
rain = np.load('rain.npy')
dates = np.load('doy.npy')
#使用日期和降雨构建数组
x = np.vstack((dates[:-1], rain[:-1]))
#定义无雨=0，小雨=-1，雨=1；
y = np.sign(rain[1:])#把三种类别和数据值的符号关联起来
classify(x.T, y)#平均准确率是57%

#iris example
iris = datasets.load_iris()
x = iris.data[:, :2]
y = iris.target
classify(x, y)#在scikit——learn数据集上平均准确率是41%
