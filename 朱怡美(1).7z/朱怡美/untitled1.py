import re
import requests
from bs4 import BeautifulSoup
import json
import pandas as pd 
from pandas.io.parsers import read_csv

def getHTMLtext(url):
    try:
        r = requests.get(url)#使用requests来发送http请求，发送get请求
        r.raise_for_status()#响应返回404，使用语句会抛出异常
        r.encoding = r.apparent_encoding#避免编码错误
        return r.text#获取响应的正文文本内容
    except:
        return ""
    
def getW():
    
    
    df = read_csv("xitonganquan.csv")#读出软件页面的链接
    url_list = df["字段1_链接"]
    
    #获取页面内容
    for url in url_list[:10]:#遍历每一个链接
        contents = []
        content = getHTMLtext(url)
        soup = BeautifulSoup(content,"html.parser")#创建BeautifulSoup对象，获取链接的内容
        
        #获取评分
        dd = soup.find_all("dd")#返回所有dd标签的列表
        dd = dd[0]#第一个dd标签
        span = dd.find_all("span")#获取dd标签中的所有span标签
                #使用正则表达式匹配内容
        span[1] = re.search(r"<span class=\"s-1 js-votepanel\">(\d.\d)+<em>分</em></span>",str(span[1]),re.DOTALL)
        span[1] = span[1].group(0)#返回第一个括号内匹配的内容
        span[1] = span[1].split(">")[1].split("<")[0]
               
        
        #获取简介文本
        breif = soup.find_all("div","breif")#找到属性为breif的div标签
        breif = breif[0]#第一个div标签
              #使用正则表达式模块匹配内容
        breif = re.search(r"<div class=\"breif\">.+<div class=\"base-info\">",str(breif),re.DOTALL)
        intro = breif.group()
              #用“”代替文本中的无用标签
        intro = re.sub(r"<div class=\"breif\">\r\n[\s]+","",intro)
        intro = re.sub(r"<br/>\r\n","",intro)
        intro = re.sub(r"[\s]*<div class=\"base-info\">","",intro)
        intro = re.sub(r"<br/>\n","",intro)
        intro = re.sub(r"\xa0","",intro)
        
        
        #获取用户评论数
              #用户评论数文档链接的头部
        comments_url_start = "http://comment.mobilem.360.cn/comment/getComments?baike="
              #用户评论数文档链接的尾部
        comments_url_end = "&c=message&a=getmessage"
             #寻找软件界面的bikename属性
        sc = soup.find_all("script")
        sc = sc[8]
        sc = sc.string
        baike_name = sc.split("'baike_name': '")[1].split("'")[0]
        
             #用户评论数文档链接的全链接，获取其中的评论数
        comments_url = comments_url_start+baike_name+comments_url_end
        comments = getHTMLtext(comments_url)
        com = comments.split('total":')[1].split(",")[0]
        
        
        #将评分、评论数、简介写入文档
        contents.append([span[1],com,intro])        
        with open("d.json","a",encoding = "utf-8") as f:
            json.dump(contents,f, ensure_ascii=False)
            
            


    
def main():
    getW()
    print("OK")
    
if __name__ =="__main__":
    main()

